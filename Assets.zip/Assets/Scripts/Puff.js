﻿#pragma strict

public var points : int = 5;
public var pickedUpBy : String = "Man";
/*
Public variables will
show up in Unity Editor
*/

function OnTriggerEnter2D(other : Collider2D) //checks for collisions
{

	if ( other.CompareTag(pickedUpBy) ) //if there is a collision, do these two things:
	{
		Debug.Log("Coin is worth " + points + " points!"); //give 5 points

		Destroy(gameObject); //destroy oneself

	}

}